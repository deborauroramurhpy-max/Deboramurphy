// Copy into Aurora app/api/alexa/route.ts after reviewing and configuring secrets.
// This file is supplied as source; it has NOT been deployed to the live Site.
import { env } from 'cloudflare:workers';
import { storage } from '../../../db/storage';
import { privateJSON, readBoundedJSON, RequestError } from '../../../lib/request-security';
export const dynamic='force-dynamic';
async function equalSecret(a:string,b:string){
 const encode=new TextEncoder();
 const [x,y]=await Promise.all([crypto.subtle.digest('SHA-256',encode.encode(a)),crypto.subtle.digest('SHA-256',encode.encode(b))]);
 const xx=new Uint8Array(x),yy=new Uint8Array(y);let diff=0;for(let i=0;i<xx.length;i++)diff|=xx[i]^yy[i];return diff===0;
}
export async function POST(request:Request){
 const config=env as unknown as Record<string,string>;
 const token=config.AURORA_BRIDGE_TOKEN,owner=config.AURORA_OWNER_USER_ID;
 // Private Site dispatch must also validate OAI-Sites-Authorization.
 if(!token||!owner)return privateJSON({error:'Not configured'},{status:503});
 const bearer=request.headers.get('Authorization')||'';
 if(bearer.length>1000||!await equalSecret(bearer,'Bearer '+token))return privateJSON({error:'Unauthorized'},{status:401});
 if(request.headers.get('Content-Type')?.split(';')[0]!=='application/json')return privateJSON({error:'JSON required'},{status:415});
 try{
 const p=await readBoundedJSON(request,4000);
 if(!p||Array.isArray(p)||typeof p!=='object'||Object.keys(p).some(k=>!['action','text','requestId'].includes(k))||!['today','next','routines','note','task'].includes(p.action)||typeof p.requestId!=='string'||p.requestId.length>200)return privateJSON({error:'Invalid request'},{status:400});
 const row=await storage().prepare('SELECT data, updated_at FROM aurora_state WHERE user_id = ?').bind(owner).first<{data:string,updated_at:string}>();
 if(!row)return privateJSON({speech:'Open Aurora and save your workspace first.'});
 const state=JSON.parse(row.data);
 const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/London',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
 const part=(type:string)=>parts.find(p=>p.type===type)!.value;
 const today=part('year')+'-'+part('month')+'-'+part('day');
 const tasks=(state.tasks||[]).filter((t:any)=>t.date===today&&!t.done).sort((a:any,b:any)=>(a.time||'99:99').localeCompare(b.time||'99:99'));
 if(p.action==='today'||p.action==='next'){
 const selected=p.action==='next'?tasks.slice(0,1):tasks.slice(0,5);
 return privateJSON({speech:selected.length?selected.map((t:any)=>(t.time?t.time+'. ':'')+t.title).join('. '):'You have no unfinished tasks for today.'});}
 if(p.action==='routines'){
 const dayName=new Intl.DateTimeFormat('en-US',{timeZone:'Europe/London',weekday:'short'}).format(new Date());
 const day=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(dayName);
 const routines=(state.routines||[]).filter((r:any)=>r.days.includes(day)).sort((a:any,b:any)=>a.time.localeCompare(b.time)).slice(0,8);
 return privateJSON({speech:routines.length?routines.map((r:any)=>r.time+'. '+r.title).join('. '):'There are no routines scheduled for today.'});}
 if(typeof p.text!=='string'||!p.text.trim()||p.text.length>500)return privateJSON({error:'Invalid text'},{status:400});
 const id='alexa:'+p.requestId;
 const list=p.action==='note'?state.notes:state.tasks;
 if(!Array.isArray(list)||list.length>=(p.action==='note'?500:1000))return privateJSON({error:'Storage limit'},{status:409});
 if(list.some((item:any)=>item.id===id))return privateJSON({speech:'This item was already saved.'});
 if(p.action==='note')list.push({id,text:p.text.trim(),bot:0});
 else list.push({id,title:p.text.trim(),date:today,time:'',minutes:15,bot:0,done:false});
 const version=crypto.randomUUID();
 const result=await storage().prepare('UPDATE aurora_state SET data = ?, updated_at = ? WHERE user_id = ? AND updated_at = ?').bind(JSON.stringify(state),version,owner,row.updated_at).run();
 if(!result.meta.changes)return privateJSON({error:'Workspace changed; check before repeating'},{status:409});
 return privateJSON({speech:p.action==='note'?'Your note was saved in Aurora.':'Your task was added to today in Aurora.'});
 }catch(e){return privateJSON({error:e instanceof RequestError?e.message:'Aurora unavailable'},{status:e instanceof RequestError?e.status:503});}
}
