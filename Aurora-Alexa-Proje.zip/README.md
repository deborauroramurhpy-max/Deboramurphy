# Project Aurora — Alexa bağlantı projesi

## Mevcut durum
Kaynak proje hazırlanmıştır. GitHub'a yayınlanmamıştır; Alexa'ya import edilmemiştir.
Aurora Site köprüsü `bridge/route.ts` kaynak dosyası olarak bulunur; canlı Aurora'ya henüz uygulanmamıştır.
Gerçek hesap eşleştirmesi ve özel sunucu ayarları tamamlanmadan kişisel veriler okunmaz veya yazılmaz.
ChatGPT/Claude motoru, serbest AI sohbeti ve otomatik Alexa hatırlatma eşitlemesi bu sürümde yoktur.
Hiçbir OpenAI/Anthropic çağrısı, ücretli API veya arka plan AI işlemi içermez.

## Hazırlanan ses işlemleri
- Günlük planı okuma: “what is my plan”
- Sıradaki tamamlanmamış görevi okuma: “what is next”
- Bugünün rutinlerini okuma: “read my routines”
- Not ekleme: “add a note …”, ardından “yes” / “no”
- Bugüne görev ekleme: “add a task …”, ardından “yes” / “no”

Giriş: “Alexa, open project aurora”. Dil English (UK). Türkçe serbest ses tanıma vaat edilmez.
Görev/not kayıtları otomatik AI analizi yapmadan eklenir. Kayıt başarısız olursa kendiliğinden tekrar denenmez.
Takvim, banka, e-posta, sağlık uygulamaları veya satın alma işlemleriyle bir bağlantı kurulmaz.

## Import
1. Bu klasörün içindekileri bir public Git deposunun köküne yayınla; ZIP'i tek dosya halinde yükleme.
2. Alexa Console → Create Skill → Custom → Alexa-hosted (Node.js) → English (UK).
3. Templates → Import Skill → gerçek deponun `.git` bağlantısını yapıştır.
4. Modeli Build et, kodu Deploy et, Test'i Development yap.
Mevcut Alexa projesine Code → Import Code ile ZIP aktarımı yalnızca lambda kodunu getirir;
ses modeli ayrıca `skill-package/interactionModels/custom/en-GB.json` içinden aktarılmalıdır.

## Özel Aurora bağlantısı — tamamlanması gereken kurulum
- `bridge/route.ts` dosyasını Aurora `app/api/alexa/route.ts` yoluna uygula, yetki ve depolama testlerini çalıştır, Site'ı mevcut özel erişim politikasıyla yayınla.
- Site'ın gerçek kayıt sahibine ait `user_id` değerini yalnızca özel Site ayarı `AURORA_OWNER_USER_ID` içinde kullan. Hesap kimliğinden tahmin etme.
- Güçlü rastgele bir `AURORA_BRIDGE_TOKEN` oluştur; Site ve Alexa'nın özel çalışma ortamına koy.
- Sites'ın desteklediği servis erişim anahtarını yalnızca Alexa sunucusunda `AURORA_SERVICE_TOKEN` olarak tut.
- Alexa-hosted çalışma ortamında bu özel ayarları desteklenen gizli yapılandırma yöntemiyle sağla. Public kod editörüne/deposuna anahtar yapıştırma. Bu paket bir gizli ayar dağıtımı yapmaz.
- Anahtarlar public Git, ZIP, README, tarayıcı kaynak kodu veya sohbet mesajlarında bulunmamalıdır.
- Canlı Echo üzerinde okuma, onaylı kayıt, reddedilen kayıt ve tekrar istek testlerini tamamla.

Köprü yalnızca bugünün görevlerini/rutinlerini döndürür. Bio, sağlık kayıtları, bütçe ve diğer kişisel alanları Alexa'ya döndürmez.
Site özel kalmalıdır. Platform servis erişimi tek başına ziyaretçi kimliği sağlamaz; köprü ek anahtar ve sabit sahip kimliğiyle kayıt erişimini sınırlar.

## Doğrulama
`node --test tests/bridge.test.js`
`node --check lambda/index.js`
Bu kontroller canlı Amazon import, Echo veya canlı Site entegrasyonu testi yerine geçmez.
